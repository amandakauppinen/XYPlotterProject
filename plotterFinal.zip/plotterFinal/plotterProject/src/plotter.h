#ifndef PLOTTER_H_
#define PLOTTER_H_
#include "DigitalIoPin.h"
#include "FreeRTOS.h"
#include "task.h"
#include <string>
#include "ITM_write.h"

#define xSizeMM 310
#define ySizeMM 345


class plotter{

private:
	//Generic limit switch objects, used on setup before calibration
	DigitalIoPin LS1;
	DigitalIoPin LS2;
	DigitalIoPin LS3;
	DigitalIoPin LS4;

	DigitalIoPin tool; // PEN/LASER PIN
	DigitalIoPin xMotor; // X MOTOR
	DigitalIoPin xMotorD; // X MOTOR DIRECTION
	DigitalIoPin yMotor; // Y MOTOR
	DigitalIoPin yMotorD; // Y MOTOR DIRECTION

	//Descriptive pointers assigned to limit switches after calibration
	DigitalIoPin *topPoint;
	DigitalIoPin *bottomPoint;
	DigitalIoPin *rightPoint;
	DigitalIoPin *leftPoint;

	int ySteps = 0;
	int xSteps = 0;

public:
	//Descriptive variables for motor movement
	enum directions{
		right,
		left,
		up,
		down,
	};
	enum axes{
		x, y,
	};

	plotter(DigitalIoPin ls1, DigitalIoPin ls2, DigitalIoPin ls3, DigitalIoPin ls4,
			DigitalIoPin pl, DigitalIoPin mX, DigitalIoPin mdX, DigitalIoPin mY, DigitalIoPin mdY):
				LS1(ls1), LS2(ls2), LS3(ls3), LS4(ls4), tool(pl), xMotor(mX), xMotorD(mdX), yMotor(mY), yMotorD(mdY) {};

	virtual ~plotter(){};
	void move(axes axis, directions dir); //Moves the plotter
	void calibrate(void (*RIT_delay)(int cnt, int us)); //Calibrates plotter
	int xSizeSteps(){return (xSteps/xSizeMM);} //Sets size of x steps
	int ySizeSteps(){return (ySteps/ySizeMM);} //Sets size of y steps
	void assignLimitSwitch(DigitalIoPin *lsPoint); //Assigns limit switch pointers in correct direction
	void limitReturn(); //Sends limit switch query reply to mDraw
};


#endif /* PLOTTERH */
