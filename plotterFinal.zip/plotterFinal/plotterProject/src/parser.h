/*
 * parser.h
 *
 *  Created on: Oct 3, 2019
 *      Author: vovan
 */

#include <string>
#include <string.h>
#include "ITM_write.h"
#ifndef PARSER_H_
#define PARSER_H_

//Struct to return after parsing g-code
struct instruction{
	int x1 = 1, x2 = 0, y1 = 1, y2 = 0, inst = 0, pen = 0;
};

class Parser{
private:
	struct instruction CurrentInstruction;

public:
	int xSizeSteps = 0;
	int ySizeSteps = 0;

	Parser(){};
	~Parser(){};

	//Parses given g-code
	void parseCode(char cd[]);

	//Returns instruction struct
	struct instruction GetInstruction();

	//Sets memeber values of step size in X and Y direction
	void setSizeSteps(int xSteps, int ySteps);

};

#endif /* PARSER_H_ */
