/*
 * LS1 = top
 * LS2 = bottom
 * LS3 = right
 * LS4 = left
 */

#include "plotter.h"

/*
 * Function for moving the X and Y motors in specified directions given direction and axis
 * Plotter only moves if none of the limit switches are closed
 * X == TRUE	Y== FALSE
 */
void plotter::move(axes axis, directions dir) {

	if (axis == x) {
		if (dir == right) {
			xMotorD.write(false);
		}
		else if (dir == left) {
			xMotorD.write(true);
		}

		if (!LS1.read() && !LS2.read() && !LS3.read() && !LS4.read()) {
			xMotor.write(false);
			xMotor.write(true);
		}
	}

	else if (axis == y) {
		if (dir == up) {
			yMotorD.write(false);
		}
		else if (dir == down) {
			yMotorD.write(true);
		}

		if (!LS1.read() && !LS2.read() && !LS3.read() && !LS4.read()) {
			yMotor.write(false);
			yMotor.write(true);
		}
	}
}

/*
 * Plotter moves around board--counts steps and sets limit switch pointers as they are hit
 * Moves in direction up, right, down, left--ends in bottom left corner
 */
void plotter::calibrate(void (*RIT_delay)(int cnt, int us)) {
	int yStepsDiff = 0;
	int xStepsDiff = 0;

	//Move up until a limit switch is read
	yMotorD.write(false);
	while (!LS1.read() && !LS2.read() && !LS3.read() && !LS4.read()) {
		yMotor.write(false);
		yMotor.write(true);
		(*RIT_delay)(1, 200);
	}

	//Call function for assigning pointer to limit switch
	assignLimitSwitch(topPoint);

	//Move down off the limit switch
	yMotorD.write(true);
	while (LS1.read() || LS2.read() || LS3.read() || LS4.read()) {
		yMotor.write(false);
		yMotor.write(true);
		(*RIT_delay)(1, 200);
	}

	//Move right until a limit switch is read
	xMotorD.write(false);
	while (!LS1.read() && !LS2.read() && !LS3.read() && !LS4.read()) {
		xMotor.write(false);
		xMotor.write(true);
		(*RIT_delay)(1, 200);
	}

	//Call function for assigning pointer to limit switch
	assignLimitSwitch(rightPoint);

	//Move left off the limit switch
	xMotorD.write(true);
	while (LS1.read() || LS2.read() || LS3.read() || LS4.read()) {
		xMotor.write(false);
		xMotor.write(true);
		(*RIT_delay)(1, 200);
	}

	//Move down until a limit switch is read
	yMotorD.write(true);
	while (!LS1.read() && !LS2.read() && !LS3.read() && !LS4.read()) {
		yMotor.write(false);
		yMotor.write(true);
		//Count amount of steps on Y axis
		ySteps++;
		(*RIT_delay)(1, 200);
	}

	//Call function for assigning pointer to limit switch
	assignLimitSwitch(bottomPoint);

	//Move up off the limit switch
	yMotorD.write(false);
	while (LS1.read() || LS2.read() || LS3.read() || LS4.read()) {
		yMotor.write(false);
		yMotor.write(true);
		(*RIT_delay)(1, 200);
		//Count steps taken off limit switch
		yStepsDiff++;
	}

	//Move left until a limit switch is read
	xMotorD.write(true);
	while (!LS1.read() && !LS2.read() && !LS3.read() && !LS4.read()) {
		xMotor.write(false);
		xMotor.write(true);
		//Count amount of steps on X axis
		xSteps++;
		(*RIT_delay)(1, 200);
	}

	//Call function for assigning pointer to limit switch
	assignLimitSwitch(leftPoint);

	//Move right off the limit switch
	xMotorD.write(false);
	while (LS1.read() || LS2.read() || LS3.read() || LS4.read()) {
		xMotor.write(false);
		xMotor.write(true);
		(*RIT_delay)(1, 200);
		//Count steps taken off limit switch
		xStepsDiff++;
	}

	//Takes off the steps after moving away from the limit switch
	ySteps -= yStepsDiff;
	xSteps -= xStepsDiff;

}

/*
 * Function is called after plotter moves in certain direction and assigns the
 * correct pointer to the direction
 *
 * Example:
 * 		Function called after moving upwards
 * 		Program assigns the limit switch hit to be the top limit switch,
 * 			even if the top limit switch has different IO pins than expected
 * 		In this way, top limit switch is now dynamic
 */
void plotter::assignLimitSwitch(DigitalIoPin *lsPoint) {
	if (LS1.read()) {
		lsPoint = &LS1;
	} else if (LS2.read()) {
		lsPoint = &LS2;
	} else if (LS3.read()) {
		lsPoint = &LS3;
	} else if (LS4.read()) {
		lsPoint = &LS4;
	}
}


/*
 * Function sends limit switch query response to mDraw based on which limit
 * switches are open and closed at the moment function is called
 */
void plotter::limitReturn() {
	char limitQuery[] = "M11 1 1 1 1\r\n";
	char ok[] = "OK\r\n";

	if (LS1.read()) {
		limitQuery[10] = '1';
	}
	else if (!LS1.read()) {
		limitQuery[10] = '0';
	}

	if (LS2.read()) {
		limitQuery[8] = '1';
	}
	else if (!LS2.read()) {
		limitQuery[8] = '0';
	}

	if (LS3.read()) {
		limitQuery[6] = '1';
	}
	else if (!LS3.read()) {
		limitQuery[6] = '0';
	}

	if (LS4.read()) {
		limitQuery[4] = '1';
	}
	else if (!LS4.read()) {
		limitQuery[4] = '0';
	}

	Board_UARTPutSTR(limitQuery);
	Board_UARTPutSTR(ok);
}
