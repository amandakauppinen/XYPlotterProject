/*
 ===============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
 ===============================================================================
 */

/*
 * Main program for XY Plotter project
 */

#if defined (__USE_LPCOPEN)
#if defined(NO_BOARD_LIB)

#include "chip.h"
#else
#include "board.h"
#include "math.h"
#endif
#endif

#include <cr_section_macros.h>
#include <string>

// TODO: insert other include files here

// TODO: insert other definitions and declarations here

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "ITM_write.h"
#include "parser.h"
#include "plotter.h"
#include "DigitalIoPin.h"
#include "event_groups.h"
#include "core_cm3.h"
#include "FreeRTOSConfig.h"

#define BIT_0 1
#define penUp 1000
#define penDown 1800
#define delayMS 200

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

void Bresen(int x1, int x2, int y1, int y2);

/*
 * isntToMotor used for passing coordinate struct from UART task to Motor task
 * calibWait used to deter other tasks from executing while calibration is running
 */
QueueHandle_t instToMotor(xQueueCreate(20, sizeof(instruction)));
EventGroupHandle_t calibWait = xEventGroupCreate();

//Global pointer for plotter object
plotter *np;

//RITimer variable setup
volatile uint32_t RIT_count;
SemaphoreHandle_t sbRIT = xSemaphoreCreateBinary();
SemaphoreHandle_t motorSem = xSemaphoreCreateBinary();

extern "C" {

void vConfigureTimerForRunTimeStats(void) {
	Chip_SCT_Init(LPC_SCTSMALL1);
	LPC_SCTSMALL1->CONFIG = SCT_CONFIG_32BIT_COUNTER;
	LPC_SCTSMALL1->CTRL_U = SCT_CTRL_PRE_L(255) | SCT_CTRL_CLRCTR_L; // set prescaler to 256 (255 + 1), and start timer
}

void RIT_IRQHandler(void) {
	// This used to check if a context switch is required
	portBASE_TYPE xHigherPriorityWoken = pdFALSE;
	// Tell timer that we have processed the interrupt.
	// Timer then removes the IRQ until next match occurs
	Chip_RIT_ClearIntStatus(LPC_RITIMER); // clear IRQ flag
	if (RIT_count > 0) {
		RIT_count--;
		xSemaphoreGiveFromISR(motorSem, &xHigherPriorityWoken);
	} else {
		Chip_RIT_Disable(LPC_RITIMER); // disable timer
		// Give semaphore and set context switch flag if a higher priority task was woken up
		xSemaphoreGiveFromISR(sbRIT, &xHigherPriorityWoken);
	}
	// End the ISR and (possibly) do a context switch
	portEND_SWITCHING_ISR(xHigherPriorityWoken);
}

}

void RIT_start(int count, int us) {
	uint64_t cmp_value;

	// Determine approximate compare value based on clock rate and passed interval
	cmp_value = (uint64_t) Chip_Clock_GetSystemClockRate() * (uint64_t) us
			/ 1000000;

	// disable timer during configuration
	Chip_RIT_Disable(LPC_RITIMER);
	RIT_count = count;

	// enable automatic clear on when compare value==timer value
	// this makes interrupts trigger periodically
	Chip_RIT_EnableCompClear(LPC_RITIMER);

	// reset the counter
	Chip_RIT_SetCounter(LPC_RITIMER, 0);
	Chip_RIT_SetCompareValue(LPC_RITIMER, cmp_value);

	// start counting
	Chip_RIT_Enable(LPC_RITIMER);

	// Enable the interrupt signal in NVIC (the interrupt controller)
	NVIC_EnableIRQ(RITIMER_IRQn);

	// wait for ISR to tell that we're done
	if (xSemaphoreTake(sbRIT, portMAX_DELAY) == pdTRUE) {
		// Disable the interrupt signal in NVIC (the interrupt controller)
		NVIC_DisableIRQ(RITIMER_IRQn);
	} else {
		// unexpected error
	}
}

void SCT_Init(void) {
	LPC_SCT0->CONFIG |= (1 << 17); // two 16-bit timers, auto limit
	LPC_SCT0->CTRL_L |= (72 - 1) << 5; // set prescaler, SCTimer/PWM clock = 1 MHz

	LPC_SCT0->MATCHREL[0].L = (20000) - 1; // match 0 @ 10/1MHz = 10 usec (100 kHz PWM freq)
	LPC_SCT0->MATCHREL[1].L = 1000; // match 1 used for duty cycle (in 10 steps)
	LPC_SCT0->EVENT[0].STATE = 0xFFFFFFFF; // event 0 happens in all states
	LPC_SCT0->EVENT[0].CTRL = (1 << 12); // match 0 condition only
	LPC_SCT0->EVENT[1].STATE = 0xFFFFFFFF; // event 1 happens in all states
	LPC_SCT0->EVENT[1].CTRL = (1 << 0) | (1 << 12); // match 1 condition only
	LPC_SCT0->OUT[0].SET = (1 << 0); // event 0 will set SCTx_OUT0
	LPC_SCT0->OUT[0].CLR = (1 << 1); // event 1 will clear SCTx_OUT0
	LPC_SCT0->CTRL_L &= ~(1 << 2); // unhalt it by clearing bit 2 of CTRL reg
}

/* Sets up system hardware */
static void prvSetupHardware(void) {
	SystemCoreClockUpdate();
	Board_Init();

	Chip_RIT_Init(LPC_RITIMER);
	// set the priority level of the interrupt
	// The level must be equal or lower than the maximum priority specified in FreeRTOS config
	// Note that in a Cortex-M3 a higher number indicates lower interrupt priority
	NVIC_SetPriority(RITIMER_IRQn,
			configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);

	Chip_SCT_Init(LPC_SCT0);

	SCT_Init();
	Chip_SWM_MovablePortPinAssign(SWM_SCT0_OUT0_O, 0, 10);

	ITM_init();
	/* Initial LED0 state is off */
}

/*
 * Calibration runs first, uses event bit to block other tasks from running
 * until calibration is finished, deletes itself upon completion because it only
 * needs to run one time on startup
 */
static void calibTask(void *pvParameters) {
	while (1) {
		LPC_SCT0->MATCHREL[1].L = penUp;
		//Calls plotter class member function for calibration
		np->calibrate(RIT_start);
		xEventGroupSetBits(calibWait, BIT_0);
		vTaskDelete(NULL);
	}
}

/*
 * UART task handles g-code retrieval and parsing, steps:
 * 		*Waits on event bit when calibration is finished, then sends the size of steps (per mm) to the parser class
 * 		*Reads chars from UART-when full string is caught, sends string to parser class which returns a struct
 * 		*Clears string, sends OK response to mDraw
 * 		*Sends struct to motor task via queue
 * 		*Repeat
 * If M10 is detected, program sends M10 reply
 */
static void uartTask(void *pvParameters) {
	char ok[] = "OK\r\n";
	char M10Reply[] = "M10 XY 380 310 0.00 0.00 A0 B0 H0 S80 U160 D90\r\n";
	int ch = 0;
	EventBits_t uxBits;
	Parser prs;
	struct instruction instCode;

	char codeString[30] = {0};
	int i = 0;
	char* check;
	char* ch1 = codeString;

	//Wait on event bit to be set at end of calibration
	uxBits = xEventGroupWaitBits(calibWait, BIT_0, pdFALSE, pdFALSE, portMAX_DELAY);
	if ((uxBits & BIT_0) != 0) {
		//Get size of steps from plotter class and transfers to parser class
		prs.setSizeSteps(np->xSizeSteps(), np->ySizeSteps());
		while (1) {
			ch = Board_UARTGetChar();
			if (ch != EOF) {
				if (ch != '\n') {
					codeString[i] = ch;
					i++;
				}

				//If full g-code has been received
				else if (ch == '\n') {
					//Check for incoming M10-If M10, reset char array and send OK to mDraw
					if ((check = strstr(ch1, "M10")) != NULL) {
						memset(codeString, 0, 30);
						Board_UARTPutSTR(M10Reply);
						Board_UARTPutSTR(ok);
						i = 0;
					}
					//If g-code is not M10
					else {
						Board_UARTPutSTR(codeString);
						Board_UARTPutSTR("\n");

						//Send g-code to parser
						prs.parseCode(codeString);

						//Receive coordinate struct and send to motor task
						instCode = prs.GetInstruction();
						xQueueSend(instToMotor, &instCode, portMAX_DELAY);

						//reset char array adn send OK to mDraw
						memset(codeString, 0, 30);
						Board_UARTPutSTR(ok);
						i = 0;
					}
				}
			}
		}
	}
}

static void Motor_Task(void *pvParameters) {
	struct instruction recInst;
	EventBits_t uxBits;

	while (1) {
		xEventGroupWaitBits(calibWait, BIT_0, pdFALSE, pdFALSE, portMAX_DELAY);
		if ((uxBits & BIT_0) != 0) {
			//Receive parser struct from queue
			if (xQueueReceive(instToMotor, &recInst, portMAX_DELAY)) {
				/*
				 * Codes set in struct for plotter instruction:
				 * 		*1	(G1)	-Go to position
				 * 		*4	(M4)	-Set laser power
				 * 		*10	(M1)	-Set pen position
				 * 		*11	(M11)	-Limit switch status query
				 * 		*28	(G28)	-Go to origin
				*/
				if (recInst.inst == 1) {
					//Move plotter to latest coordinate
					Bresen(recInst.x1, recInst.x2, recInst.y1, recInst.y2);
				}
				else if(recInst.inst == 4) {
					/*
					 * Did not test laser functionality, but here is where it
					 * would be processed when correlating g-code would be received
					 */
				}
				else if (recInst.inst == 10) {
					/*
					 * Check that pen is not already set to desired position and change
					 * accordingling
					*/
					if (recInst.pen == 90 && LPC_SCT0->MATCHREL[1].L != penDown) {
						LPC_SCT0->MATCHREL[1].L = penDown;
					} else if (recInst.pen == 160 && LPC_SCT0->MATCHREL[1].L != penUp) {
						LPC_SCT0->MATCHREL[1].L = penUp;
					}
					vTaskDelay(150);
				}
				else if (recInst.inst == 11) {
					//LimitReturn sends M11 reply to UART
					np->limitReturn();
				}
				else if (recInst.inst == 28) {
					Bresen(recInst.x1, 1, recInst.y1, 1);
				}
			}
		}
	}
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* end runtime statictics collection */

/**
 * @brief	main routine for FreeRTOS blinky example
 * @return	Nothing, function should not exit
 */
int main(void) {
	prvSetupHardware();

	DigitalIoPin ls1(1, 3, DigitalIoPin::pullup, true);
	DigitalIoPin ls2(0, 0, DigitalIoPin::pullup, true);
	DigitalIoPin ls3(0, 29, DigitalIoPin::pullup, true);
	DigitalIoPin ls4(0, 9, DigitalIoPin::pullup, true);

	DigitalIoPin laser(0, 12, DigitalIoPin::output, true);
	DigitalIoPin pen(0, 10, DigitalIoPin::output, true);
	DigitalIoPin yMotor(0, 27, DigitalIoPin::output, true);
	DigitalIoPin yMotorDir(0, 28, DigitalIoPin::output, true);
	DigitalIoPin xMotor(0, 24, DigitalIoPin::output, true);
	DigitalIoPin xMotorDir(1, 0, DigitalIoPin::output, true);

	plotter plotter(ls1, ls2, ls3, ls4, pen, xMotor, xMotorDir, yMotor, yMotorDir);

	//Call if laser is to be used
	//plotter temp(ls1, ls2, ls3, ls4, laser, xMotor, xMotorDir, yMotor, yMotorDir);

	//Assign global plotter pointer to plotter object
	np = &plotter;


	xTaskCreate(calibTask, "calibTask",
	configMINIMAL_STACK_SIZE * 2, NULL, (tskIDLE_PRIORITY + 1UL),
			(TaskHandle_t *) NULL);

	xTaskCreate(uartTask, "uartTask",
	configMINIMAL_STACK_SIZE * 3, NULL, (tskIDLE_PRIORITY + 1UL),
			(TaskHandle_t *) NULL);

	xTaskCreate(Motor_Task, "Motor_Task",
	configMINIMAL_STACK_SIZE * 2, NULL, (tskIDLE_PRIORITY + 1UL),
			(TaskHandle_t *) NULL);

	/* Start the scheduler */
	vTaskStartScheduler();

	/* Should never arrive here */
	return 1;
}

/*
 * Bresenham algorithm function
 * Moves plotter based on incoming and past coordinates
 */
void Bresen(int x1, int x2, int y1, int y2) {
	int dx = x2 - x1;
	int dy = y2 - y1;
	int eps = 0;

	if (xSemaphoreTake(motorSem, portMAX_DELAY) == pdTRUE) {
		if (abs(dx) > abs(dy)) {
			int y = y1;
			if (dx > 0 && dy > 0) {
				for (int x = x1; x <= x2; x++) {
					np->move(plotter::x, plotter::right);
					RIT_start(1, delayMS);
					eps += dy;
					if ((eps << 1) >= dx) {
						np->move(plotter::y, plotter::up);
						RIT_start(1, delayMS);
						y++;
						eps -= dx;
					}
				}
			}

			if (dx > 0 && dy < 0) {
				for (int x = x1; x <= x2; x++) {
					np->move(plotter::x, plotter::right);
					RIT_start(1, delayMS);
					eps += dy;
					if ((eps << 1) <= dx) {
						np->move(plotter::y, plotter::down);
						RIT_start(1, delayMS);
						y++;
						eps += dx;
					}
				}
			}

			if (dx < 0 && dy < 0) {
				for (int x = x1; x >= x2; x--) {
					np->move(plotter::x, plotter::left);
					RIT_start(1, delayMS);
					eps += dy;
					if ((eps << 1) <= dx) {
						np->move(plotter::y, plotter::down);
						RIT_start(1, delayMS);
						y--;
						eps -= dx;
					}

				}
			}

			if (dx < 0 && dy > 0) {
				for (int x = x1; x >= x2; x--) {
					np->move(plotter::x, plotter::left);
					RIT_start(1, delayMS);
					eps += dy;
					if ((eps << 1) >= dx) {
						np->move(plotter::y, plotter::up);
						RIT_start(1, delayMS);
						y++;
						eps += dx;
					}
				}
			}

			if (dx == 0 && dy > 0) {
				for (int i = y1; i <= y2; i++) {
					np->move(plotter::y, plotter::up);
					RIT_start(1, delayMS);
				}
			}

			if (dx == 0 && dy < 0) {
				for (int i = y1; i >= y2; i--) {
					np->move(plotter::y, plotter::down);
					RIT_start(1, delayMS);
				}
			}

			if (dx > 0 && dy == 0) {
				for (int i = x1; i <= x2; i++) {
					np->move(plotter::x, plotter::right);
					RIT_start(1, delayMS);
				}
			}

			if (dx < 0 && dy == 0) {
				for (int i = x1; i >= x2; i--) {
					np->move(plotter::x, plotter::left);
					RIT_start(1, delayMS);
				}
			}
		}

		//IF HEIGHT IS LONGER THAN WIDTH
		else if (abs(dx) < abs(dy)) {
			int x = x1;

			if (dx > 0 && dy > 0) {
				for (int y = y1; y <= y2; y++) {
					np->move(plotter::y, plotter::up);
					RIT_start(1, delayMS);
					eps += dx;
					if ((eps << 1) >= dy) {
						np->move(plotter::x, plotter::right);
						RIT_start(1, delayMS);
						x++;
						eps -= dy;
					}

				}
			}

			if (dx > 0 && dy < 0) {
				for (int y = y1; y >= y2; y--) {
					np->move(plotter::y, plotter::down);
					RIT_start(1, delayMS);
					eps += dx;
					if ((eps << 1) >= dx) {
						np->move(plotter::x, plotter::right);
						RIT_start(1, delayMS);
						x++;
						eps += dy;
					}
				}
			}

			if (dx < 0 && dy < 0) {
				for (int y = y1; y >= y2; y--) {
					np->move(plotter::y, plotter::down);
					RIT_start(1, delayMS);
					eps += dx;
					if ((eps << 1) <= dx) {
						np->move(plotter::x, plotter::left);
						RIT_start(1, delayMS);
						x--;
						eps -= dy;
					}
				}
			}

			if (dx < 0 && dy > 0) {
				for (int y = y1; y <= y2; y++) {
					np->move(plotter::y, plotter::up);
					RIT_start(1, delayMS);
					eps += dx;
					if ((eps << 1) <= dy) {
						np->move(plotter::x, plotter::left);
						RIT_start(1, delayMS);
						x++;
						eps += dy;
					}
				}
			}

			if (dx == 0 && dy > 0) {
				for (int i = y1; i <= y2; i++) {
					np->move(plotter::y, plotter::up);
					RIT_start(1, delayMS);
				}
			}

			if (dx == 0 && dy < 0) {
				for (int i = y1; i >= y2; i--) {
					np->move(plotter::y, plotter::down);
					RIT_start(1, delayMS);
				}
			}

			if (dx > 0 && dy == 0) {
				for (int i = x1; i <= x2; i++) {
					np->move(plotter::x, plotter::right);
					RIT_start(1, delayMS);
				}
			}

			if (dx < 0 && dy == 0) {
				for (int i = x1; i >= x2; i--) {
					np->move(plotter::x, plotter::left);
					RIT_start(1, delayMS);
				}
			}
		}
		else {}
		xSemaphoreGive(motorSem);
	}
}
