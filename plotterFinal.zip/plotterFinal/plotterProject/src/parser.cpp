/*
 * Parser class for incoming g-codes
 */
#include "parser.h"


void Parser::parseCode(char cd[])
{
	/*
	 * Set up for parser function
	 */
	char * ch;

	char InstArr[10];
	char XArr[10];
	char YArr[10];
	char AArr[10];

	char* Instp = InstArr;
	char* Xp = XArr;
	char* Yp = YArr;
	char* Ap = AArr;

	char delim[] = " XY";
	int i = 0;

	ch = strtok(cd, delim);

	/*
	 * Iterate through incoming char array
	 * Parse sections based on delimiters
	 */
	while (ch != NULL)
	{
		if (i == 0) {
			Instp = ch;
		}
		if (i == 1)
		{
			Xp = ch;
		}
		if (i == 2)
		{
			Yp = ch;
		}
		if (i == 3)
		{
			Ap = ch;
		}
		ch = strtok(NULL, delim);
		i++;
	}
	char* check;

	//Go to position
	if((check = strstr(Instp, "G1")) != NULL) {
		CurrentInstruction.inst = 1; CurrentInstruction.pen = 0;
	}

	//Limit switch query
	else if((check = strstr(Instp, "M11")) != NULL) {
		CurrentInstruction.inst = 11;
	}

	//Set pen position
	else if((check = strstr(Instp, "M1")) != NULL)
	{
		CurrentInstruction.inst = 10;
		CurrentInstruction.pen = atoi(Xp);
	}

	//Set laser value
	else if((check = strstr(Instp, "M4")) != NULL) {
		CurrentInstruction.inst = 4; CurrentInstruction.pen = 0;;
	}

	//Go to origin
	else if((check = strstr(Instp, "G28")) != NULL) {
		CurrentInstruction.inst = 28;
		CurrentInstruction.pen = atoi(Xp);
	}

	/*
	 * Assign X and Y coordinates
	 * If there it is the first set of coordinates, goes to else if condition
	 * All other coordinates enter if, set new coordinates in X2,Y2 and replace X1,Y1 with previous set
	 */
	if(CurrentInstruction.x2 != 0 && CurrentInstruction.y2 != 0 && (check = strstr(Instp, "G1")) != NULL)
	{
		CurrentInstruction.x1 = CurrentInstruction.x2;
		CurrentInstruction.y1 = CurrentInstruction.y2;

		CurrentInstruction.x2 = atof(Xp) * xSizeSteps;
		CurrentInstruction.y2 = atof(Yp) * ySizeSteps;
	}
	else if(CurrentInstruction.x1 != 0 && CurrentInstruction.y1 != 0 && (check = strstr(Instp, "G1")) != NULL) //CHECK IF ALREADY HAS COORDINATE
	{
		CurrentInstruction.x1 = xSizeSteps;
		CurrentInstruction.y1 = ySizeSteps;

		CurrentInstruction.x2 = atof(Xp) * xSizeSteps;
		CurrentInstruction.y2 = atof(Yp) * ySizeSteps;
	}
}


//Returns struct of all instructions
struct instruction Parser::GetInstruction(){
	return CurrentInstruction;
}

//Sets step size, from plotter class
void Parser::setSizeSteps(int xSteps, int ySteps) {
	xSizeSteps = xSteps;
	ySizeSteps = ySteps;
}
